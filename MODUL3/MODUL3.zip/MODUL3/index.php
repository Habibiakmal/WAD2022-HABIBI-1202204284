<?php

require './pages/Home.php';
