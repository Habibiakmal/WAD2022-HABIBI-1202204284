<?php
$host = "localhost:4306";
$user = "root";
$pass = "";
$db = "moduL3";

$conn = new mysqli($host, $user, $pass, $db);
